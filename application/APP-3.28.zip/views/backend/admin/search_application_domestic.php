<span style="background-color: #5949fe;color: #ffffff;font-size: x-small;">UI No: FANS3231</span> <!-- UI Number -->
<script type="text/javascript">
    document.getElementById('application_page').style = 'background-color: #7467f0;color: white;';
</script>
<div class="container-xxl flex-grow-1 container-p-y">
    <form action="<?php echo site_url('user/search_application_domestic/search'); ?>" method = "post">
        <div class="row">
            <div class="col-md-8">
                <h6 class="fw-bold py-3 ms-4"><span><?= get_phrase('Student application') ?> |</span><span class="purple-text" style=" color: #7467f0; "> <?= get_phrase('Applicant Search') ?></span></h6>
            </div>
            <div class="col-md-4" style="text-align: right;">

                <div class="btn-group" role="group" aria-label="Button Set">
                    <a type="button" class="btn btn-secondary waves-effect waves-light"  href="javascript:history.go(-1)"><?= get_phrase('Back') ?></a>
                    
                    <button type="submit" class="btn btn-primary waves-effect waves-light"><?= get_phrase('Search') ?></button>
                </div>

            </div>
        </div>
        <div class="accordion" id="collapsibleSection">

            <div class="card active" data-select2-id="43">
                <div id="account-details" class="content">
                    <h2 class="accordion-header" id="headingDeliveryAddress">
                        <button type="button" class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapseDeliveryAddress" aria-expanded="true" aria-controls="collapseDeliveryAddress">
                            <?= get_phrase('Search Filters') ?>
                        </button>
                    </h2>
                    <div id="collapseDeliveryAddress" class="accordion-collapse collapse show" data-bs-parent="#collapsibleSection" style="">
                        <div class="accordion-body">

                            <Small><?= get_phrase('You can search with any of bellow fields') ?> </Small>
                            <hr>
                            <!--load content -->
                            <div class="row mt-2">
                                <div class="col-md-2"><?= get_phrase('Applicant ID') ?>:</div>
                                <div class="col-md-4 form-check">
                                    <input type="text" class="ms-1 form-control form-input1 " aria-label="Applicant ID" id="applicant_id" name="applicant_id" <?php if ($this->session->userdata('applicant_id') != '') { ?> value='<?php echo $this->session->userdata('applicant_id') ?>' <?php } ?> disabled="">
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-2"><?= get_phrase('Applicant Name') ?>:<br>
                                    <smal style="font-size: x-small;color: #7467f0;">(<?= get_phrase('kanji, Alphabet') ?>) </smal>
                                </div>
                                <div class="col-md-4 form-check">
                                    <input type="text" class="ms-1 form-control form-input1 " aria-label="Student Name"  id="kanji_lname" name="student_name_kanji" <?php if ($this->session->userdata('student_name') != '') { ?> value='<?php echo $this->session->userdata('student_name') ?>' <?php } ?>>
                                </div>
                                <div class="col-md-2"><?= get_phrase('Applicant Name') ?>:<br>
                                    <smal style="font-size: x-small;color: #7467f0;">(<?= get_phrase('Romaji') ?>) </smal>
                                </div>
                                <div class="col-md-4 form-check">
                                    <input type="text" class="ms-1 form-control form-input1 " aria-label="Student Name"  id="kanji_lname" name="student_name_romaji" <?php if ($this->session->userdata('student_name') != '') { ?> value='<?php echo $this->session->userdata('student_name') ?>' <?php } ?>>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-2"><?= get_phrase('Nationality') ?>:</div>
                                <div class="col-md-4 form-check">
                                    <input type="text" class="ms-1 form-control form-input1"  aria-label="Nationality" id="romaji_fname" name="nationalitye" <?php if ($this->session->userdata('nationality') != '') { ?> value='<?php echo $this->session->userdata('nationality') ?>' <?php } ?> disabled="" >
                                </div>
                                <div class="col-md-2"><?= get_phrase('Desired enrollment date') ?>:</div>
                                <div class="col-md-4 form-check">
                                    <input type="text" class="ms-1 form-control form-input1 " id="romajii_lname" name="desired_enrollment_date" aria-label="Last name" <?php if ($this->session->userdata('desired_enrollment_date') != '') { ?> value='<?php echo $this->session->userdata('desired_enrollment_date') ?>' <?php } ?> disabled="" >
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-2"><?= get_phrase('Application Status') ?>:</div>

                                <div class="col-md-4 form-check ">
                                    <select name="application_status" id="citizenship" class="ms-1 form-control form-input1 dropdown-toggl  dropdown-toggle waves-effect waves-light" >
                                        <option value=""><?= get_phrase('Select Status') ?></option>
                                        <option value="Registered"><?= get_phrase('Registered') ?></option>
                                        <option value="Documents Reserved"><?= get_phrase('Documents Reserved') ?></option>
                                        <option value="Immigration Submitted"><?= get_phrase('Immigration Submitted') ?></option>
                                        <option value="Examination Result"><?= get_phrase('Examination Result') ?></option>
                                        <option value="Invoice"><?= get_phrase('Invoice') ?></option>
                                        <option value="Tulition Fee Reserved"><?= get_phrase('Tulition Fee Reserved') ?></option>
                                    </select>
                                </div>
                                <div class="col-md-2"><?= get_phrase('Where to apply') ?>:
                                </div>
                                <div class="col-md-4 form-check">
                                    <input type="text" class="ms-1 form-control form-input1 " id="romajii_lname" name="where_to_apply" aria-label="where_to_apply" <?php if ($this->session->userdata('where_to_apply') != '') { ?> value='<?php echo $this->session->userdata('where_to_apply') ?>' <?php } ?> disabled="" >
                                </div>

                            </div>

                        </div>
                    </div>

                </div>
            </div>
            <div class="card accordion-item">
                <h2 class="accordion-header" id="headingDeliveryOptions">
                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseDeliveryOptions" aria-expanded="false" aria-controls="collapseDeliveryOptions">
                        <?= get_phrase('Search Result') ?>
                    </button>
                </h2>
                <div id="collapseDeliveryOptions" class="accordion-collapse collapse <?php
                if (isset($search_result)) {
                    echo 'show';
                }
                ?>" aria-labelledby="headingDeliveryOptions" data-bs-parent="#collapsibleSection" style="">
                    <div class="accordion-body">
                        <hr>
                        <div class="row">
                            <!-- Result View load here -->
                            <div class="table-responsive text-nowrap">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th><?= get_phrase('Applicantt ID') ?></th>
                                            <th><?= get_phrase('Student Name') ?></th>
                                            <th><?= get_phrase('Created Date') ?></th>
                                            <th><?= get_phrase('Application Status') ?></th>                                    
                                            <th><?= get_phrase('Actions') ?></th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-border-bottom-0">
                                        <?php if (isset($search_result)) { ?>                                        
                                            <?php foreach ($search_result->result_array() as $key => $student) : ?>
                                                <tr>
                                                    <td><?php echo $student['id']; ?></td>
                                                    <td><?php echo $student['kanji_fn'].' '. $student['kanji_ln']; ?></td>
                                                    <td><?php echo $student['created_at']; ?></td>
                                                    <td></td>                                                
                                                    <td style="width:15%">
                                                        <a  href="<?php echo site_url('user/student_application_domestic/view/' . $student['id']) ?>" data-toggle="tooltip" data-placement="top" title="<?php echo get_phrase('view_profile'); ?>">
                                                            <span><i class="menu-icon tf-icons ti ti-eye"></i></span>
                                                        </a>
                                                        <a href="<?php echo site_url('user/student_application_domestic/edit/' . $student['id']) ?>" data-toggle="tooltip" data-placement="top" title="<?php echo get_phrase('edit_profile'); ?>">
                                                            <span><i class="menu-icon tf-icons ti ti-edit"></i></span>
                                                        </a>
                                                        <a href="javascript:;" data-bs-target="#deleteStudent<?php $student['id']; ?>" data-bs-toggle="modal"><span><i class="menu-icon tf-icons ti ti-trash"></span></i></a>
                                                    </td>
                                                    <!-- Render other student details here -->
                                                </tr>                                        
                                                <!-- Delete Student -->
                                            <div class="modal fade" id="deleteStudent<?php $student['id']; ?>" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                                    <div class="modal-content p-3 p-md-5">
                                                        <div class="modal-body">
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            <div class="text-center mb-4">
                                                                <img src="../../assets/img/remove.gif" style="width: 50%;"> 
                                                                <h3 class="mb-2" style="color : #7367f0"><?php echo get_phrase('Are you sure'); ?>?</h3>  
                                                                <p><?php echo get_phrase('Do You Want To Remove This Student Application ?'); ?></p>
                                                            </div>
                                                            <div class="text-center mb-4">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo get_phrase('No'); ?></button>
                                                                <a href="<?php echo site_url('user/student_application/delete/' . $student['id']) ?>" class="btn btn-danger" role="button"><?php echo get_phrase('Yes'); ?></a>                                                    
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php } ?>

                                    </tbody>
                                </table>
                            </div>

                            <!-- ENd Result -->
                        </div>
                    </div>
                </div>
                </form>   
            </div>                         
