<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 15">
<meta name=Originator content="Microsoft Word 15">
<link rel=File-List
href="FOREIGN%20APPLICANT%20MANAGEMENT%20SYSTEM.fld/filelist.xml">
<link rel=Edit-Time-Data
href="FOREIGN%20APPLICANT%20MANAGEMENT%20SYSTEM.fld/editdata.mso">

<link rel=themeData
href="FOREIGN%20APPLICANT%20MANAGEMENT%20SYSTEM.fld/themedata.thmx">
<link rel=colorSchemeMapping
href="FOREIGN%20APPLICANT%20MANAGEMENT%20SYSTEM.fld/colorschememapping.xml">

<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:-536870145 1107305727 0 0 415 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-536859905 -1073732485 9 0 511 0;}
@font-face
	{font-family:"Arial Unicode MS";
	panose-1:2 11 6 4 2 2 2 2 2 4;
	mso-font-charset:128;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-134238209 -371195905 63 0 4129279 0;}
@font-face
	{font-family:"Helvetica Neue";
	panose-1:2 0 5 3 0 0 0 2 0 4;
	mso-font-alt:"Helvetica Neue";
	mso-font-charset:0;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:-452984065 1342208475 16 0 1 0;}
@font-face
	{font-family:"Century Gothic";
	panose-1:2 11 5 2 2 2 2 2 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:647 0 0 0 159 0;}
@font-face
	{font-family:"Iskoola Pota";
	panose-1:2 11 5 2 4 2 4 2 2 3;
	mso-font-charset:77;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:3 0 512 0 1 0;}
@font-face
	{font-family:-webkit-standard;
	panose-1:2 11 6 4 2 2 2 2 2 4;
	mso-font-alt:Cambria;
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:auto;
	mso-font-signature:0 0 0 0 0 0;}
@font-face
	{font-family:"\@Arial Unicode MS";
	panose-1:2 11 6 4 2 2 2 2 2 4;
	mso-font-charset:128;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-134238209 -371195905 63 0 4129279 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin:0cm;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Calibri",sans-serif;
	mso-fareast-font-family:Calibri;
	mso-bidi-font-family:"Arial Unicode MS";
	mso-fareast-language:EN-US;
	mso-bidi-language:SI-LK;}
a:link, span.MsoHyperlink
	{mso-style-noshow:yes;
	mso-style-priority:99;
	color:#0563C1;
	text-decoration:underline;
	text-underline:single;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-noshow:yes;
	mso-style-priority:99;
	color:#954F72;
	mso-themecolor:followedhyperlink;
	text-decoration:underline;
	text-underline:single;}
span.apple-converted-space
	{mso-style-name:apple-converted-space;
	mso-style-unhide:no;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
@page WordSection1
	{size:595.3pt 841.9pt;
	margin:72.0pt 72.0pt 72.0pt 72.0pt;
	mso-header-margin:35.4pt;
	mso-footer-margin:35.4pt;
	mso-paper-source:0;}
div.WordSection1
	{page:WordSection1;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin:0cm;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1027"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=en-LK link="#0563C1" vlink="#954F72" style='tab-interval:36.0pt;
word-wrap:break-word'>

<div class=WordSection1>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=822
 style='width:616.5pt;background:white;border-collapse:collapse;mso-yfti-tbllook:
 1184;mso-padding-alt:0cm 0cm 0cm 0cm'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td style='padding:0cm 0cm 0cm 0cm'>
  <p class=MsoNormal><span style='font-size:1.0pt;font-family:"-webkit-standard",serif'>&nbsp;</span><span
  style='font-size:1.0pt;font-family:"-webkit-standard",serif;mso-bidi-font-family:
  Calibri'><o:p></o:p></span></p>
  </td>
  <td width=580 valign=top style='width:435.0pt;padding:0cm 0cm 0cm 0cm'>
  <div align=center>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=580
   style='width:435.0pt;border-collapse:collapse;mso-yfti-tbllook:1184;
   mso-padding-alt:0cm 0cm 0cm 0cm'>
   <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
    <td style='padding:0cm 0cm 0cm 0cm'>
    <div align=center>
    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=580
     style='width:435.0pt;border-collapse:collapse;mso-yfti-tbllook:1184;
     mso-padding-alt:0cm 0cm 0cm 0cm'>
     <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
      <td style='border:none;border-bottom:solid #CCCCCC 1.0pt;mso-border-bottom-alt:
      solid #CCCCCC .75pt;padding:30.0pt 0cm 30.0pt 0cm'>
		  
      <p class=MsoNormal><b><span lang=EN-US style='font-size:16.0pt;
      color:#7030A0;mso-ansi-language:EN-US'><img src="<?= base_url('/assets/img/logo.png'); ?>" height="25px">FOREIGN APPLICANT MANAGEMENT
      SYSTEM</span></b><span lang=EN-US style='font-size:11.0pt;mso-ansi-language:
      EN-US'><o:p></o:p></span></p>
      </td>
     </tr>
     <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes;height:15.0pt'>
      <td style='padding:0cm 0cm 0cm 0cm;height:15.0pt'>
      <p class=MsoNormal style='line-height:15.0pt'><span style='font-size:
      1.0pt'>&nbsp;<span class=apple-converted-space>&nbsp;</span><o:p></o:p></span></p>
      </td>
     </tr>
    </table>
    </div>
    </td>
   </tr>
   <tr style='mso-yfti-irow:1'>
    <td style='padding:0cm 0cm 0cm 0cm'>
    <div align=center>
    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=580
     style='width:435.3pt;border-collapse:collapse;mso-yfti-tbllook:1184;
     mso-padding-alt:0cm 0cm 0cm 0cm'>
     <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
      <td style='padding:0cm 0cm 0cm 0cm'>
      <div align=center>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       width=580 style='width:435.0pt;border-collapse:collapse;mso-yfti-tbllook:
       1184;mso-padding-alt:0cm 0cm 0cm 0cm'>
       <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
        <td style='padding:15.0pt 0cm 0cm 0cm'>
        <p class=MsoNormal style='line-height:26.25pt'><b><span lang=EN-US
        style='font-size:18.0pt;font-family:"Helvetica Neue";color:#253858;
        mso-ansi-language:EN-US'>Congratulations! </span></b><b><span
        style='font-size:18.0pt;font-family:"Helvetica Neue";mso-bidi-font-family:
        Calibri;color:#253858'><o:p></o:p></span></b></p>
        </td>
       </tr>
      </table>
      </div>
      </td>
      <td valign=top style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='line-height:26.25pt'><b><span lang=EN-US
      style='font-size:18.0pt;font-family:"Helvetica Neue";color:#253858;
      mso-ansi-language:EN-US'><o:p>&nbsp;</o:p></span></b></p>
      </td>
     </tr>
     <tr style='mso-yfti-irow:1'>
      <td style='padding:30.0pt 0cm 0cm 0cm'>
      <p class=MsoNormal style='line-height:16.5pt'><span style='font-family:
      "Helvetica Neue";color:#42526E'>Hi <?= $to_name; ?>,<span
      class=apple-converted-space>&nbsp;</span></span><span style='font-family:
      "Helvetica Neue";mso-bidi-font-family:Calibri;color:#42526E'><o:p></o:p></span></p>
      </td>
      <td valign=top style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='line-height:16.5pt'><span style='font-family:
      "Helvetica Neue";color:#42526E'><o:p>&nbsp;</o:p></span></p>
      </td>
     </tr>
     <tr style='mso-yfti-irow:2'>
      <td style='padding:15.0pt 0cm 0cm 0cm'>
      <p class=MsoNormal style='line-height:16.5pt'><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'>We
      are glad to inform that your Domestic User account has been created on
      Foreign Applicant Management System. Please kindly login with default
      login credentials bellow to access your portal. <o:p></o:p></span></p>
      <p class=MsoNormal style='line-height:16.5pt'><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'><o:p>&nbsp;</o:p></span></p>
      <p class=MsoNormal style='line-height:16.5pt'><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'>URL:
      </span><strong><span style='font-family:"Helvetica Neue";mso-bidi-font-family:
      "Arial Unicode MS";color:#42526E'> <a href="<?= base_url('login/'); ?>">Login to FAMS Poral</a> </span></strong><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'><o:p></o:p></span></p>
      <p class=MsoNormal style='line-height:16.5pt'><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'>User
      Email:<strong><span style='font-family:"Helvetica Neue";mso-bidi-font-family:
      "Arial Unicode MS"'> </span></strong></span><strong><span
      style='font-family:"Helvetica Neue";mso-bidi-font-family:"Arial Unicode MS";
      color:#42526E'><?= $this->session->userdata('email') ?></span></strong><span lang=EN-US style='font-family:
      "Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'><o:p></o:p></span></p>
      <p class=MsoNormal style='line-height:16.5pt'><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'>Password:
      </span><strong><span style='font-family:"Helvetica Neue";mso-bidi-font-family:
      "Arial Unicode MS";color:#42526E'><?= $verification_code; ?></span></strong><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'><o:p></o:p></span></p>
      </td>
      <td valign=top style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='line-height:16.5pt'><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'><o:p>&nbsp;</o:p></span></p>
      </td>
     </tr>
     <tr style='mso-yfti-irow:3'>
      <td style='padding:15.0pt 0cm 0cm 0cm'>
      <p class=MsoNormal style='line-height:16.5pt'><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'>You
      can change your password after whenever you needed</span><span
      style='font-family:"Helvetica Neue";color:#42526E'>.<span
      class=apple-converted-space>&nbsp;</span><o:p></o:p></span></p>
      </td>
      <td valign=top style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='line-height:16.5pt'><span lang=EN-US
      style='font-family:"Helvetica Neue";color:#42526E;mso-ansi-language:EN-US'><o:p>&nbsp;</o:p></span></p>
      </td>
     </tr>
     <tr style='mso-yfti-irow:4'>
      <td style='padding:30.0pt 0cm 0cm 0cm;border-radius: 3px'>
      <div align=center>
      
      </div>
      </td>
      <td valign=top style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal align=center style='text-align:center'><span
      style='color:white'><o:p>&nbsp;</o:p></span></p>
      </td>
     </tr>
     <tr style='mso-yfti-irow:5;mso-yfti-lastrow:yes'>
      <td style='padding:30.0pt 0cm 0cm 0cm'>
      <p class=MsoNormal style='line-height:16.5pt'><span style='font-family:
      "Helvetica Neue";color:#42526E'>Cheers,<br>
      </span><span lang=EN-US style='mso-ansi-language:EN-US'>F</span>orign
      Management <span lang=EN-US style='mso-ansi-language:EN-US'>system</span><span
      class=apple-converted-space><span style='font-family:"Helvetica Neue";
      color:#42526E'>&nbsp;</span></span><span style='font-family:"Helvetica Neue";
      mso-bidi-font-family:Calibri;color:#42526E'><o:p></o:p></span></p>
      </td>
      <td valign=top style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='line-height:16.5pt'><span style='font-family:
      "Helvetica Neue";color:#42526E'><o:p>&nbsp;</o:p></span></p>
      </td>
     </tr>
    </table>
    </div>
    </td>
   </tr>
   <tr style='mso-yfti-irow:2;mso-yfti-lastrow:yes'>
    <td style='padding:0cm 0cm 0cm 0cm'>
    <div align=center>
    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=580
     style='width:435.0pt;border-collapse:collapse;mso-yfti-tbllook:1184;
     mso-padding-alt:0cm 0cm 0cm 0cm'>
     <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
      <td style='padding:30.0pt 0cm 30.0pt 0cm'>
      <div align=center>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       width=580 style='width:435.0pt;border-collapse:collapse;mso-yfti-tbllook:
       1184;mso-padding-alt:0cm 0cm 0cm 0cm'>
       <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
        <td style='border:none;border-top:solid #CCCCCC 1.0pt;mso-border-top-alt:
        solid #CCCCCC .75pt;padding:30.0pt 0cm 0cm 0cm'>
        <p class=MsoNormal align=center style='text-align:center;line-height:
        14.25pt'><span lang=EN-US style='font-size:10.0pt;font-family:"Helvetica Neue";
        color:#707070;mso-ansi-language:EN-US'>This is a system generated
        email, please do not reply to this as there’s no human interaction on</span><span
        style='font-size:10.0pt;font-family:"Helvetica Neue";color:#707070'>.<span
        class=apple-converted-space>&nbsp;</span></span><span style='font-size:
        10.0pt;font-family:"Helvetica Neue";mso-bidi-font-family:Calibri;
        color:#707070'><o:p></o:p></span></p>
        </td>
       </tr>
       <tr style='mso-yfti-irow:1'>
        <td style='padding:7.5pt 0cm 0cm 0cm'></td>
       </tr>
       <tr style='mso-yfti-irow:2'>
        <td style='padding:7.5pt 0cm 0cm 0cm'>
        <p class=MsoNormal align=center style='text-align:center;line-height:
        14.25pt'><span style='font-size:10.0pt;font-family:"Helvetica Neue";
        color:#707070'>Copyright 2024 </span><span lang=EN-US style='font-size:
        10.0pt;font-family:"Helvetica Neue";color:#707070;mso-ansi-language:
        EN-US'>Daiki Engineering</span><span style='font-size:10.0pt;
        font-family:"Helvetica Neue";color:#707070'> Ltd. All rights reserved. <o:p></o:p></span></p>
        </td>
       </tr>

      </table>
      </div>
      </td>
     </tr>
    </table>
    </div>
    </td>
   </tr>
  </table>
  </div>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm'>
  <p class=MsoNormal><span style='font-size:1.0pt;font-family:"-webkit-standard",serif;
  color:black;mso-color-alt:windowtext'>&nbsp;</span><span style='font-size:
  1.0pt;font-family:"-webkit-standard",serif;mso-bidi-font-family:Calibri'><o:p></o:p></span></p>
  </td>
 </tr>
</table>

</div>


</div>

</body>

</html>
