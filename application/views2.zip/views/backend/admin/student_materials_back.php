<span style="background-color: #5949fe;color: #ffffff;font-size: x-small;">UI No: FAMS5300</span> <!-- UI Number -->
<link rel="stylesheet" href="<?php echo base_url('assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.css'); ?>" />
<link rel="stylesheet" href="<?php echo base_url('assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.css'); ?>" />
<script type="text/javascript">
    document.getElementById('application_page').style = 'background-color: #7467f0;color: white;';
</script>
<style>
    .answer {
        color: #355089 !important;
    }

    small {
        font-size: x-small;
        color: #7467f0;
    }

    .red:hover {
        background-color: #dd4b39 !important;
    }

    .green:hover {
        background-color: #28c76f !important;
    }

    .blue:hover {
        background-color: #7567f0 !important;
    }

    .u {
        text-decoration: underline;
        color: color(srgb 0.645 0.645 0.645);
    }
    #showMe{
    display:none;
    }
    .mandatory {
    border-color: #8682a8 !important;
}
</style>
<script type="text/javascript">
    function addDashes(f) {
        f.value = f.value.slice(0, 3) + "-" + f.value.slice(3, 6) + "-" + f.value.slice(6, 10);
    }
</script>
<!-- Content wrapper ------------------------------------------------------------------------------------------------------------------------------------------>
<div class="container-xxl flex-grow-1 container-p-y" >

    <div class="row">
        <div class="col-md-7">
            <h6 class="fw-bold py-3 ms-4"><span><?= get_phrase('Application Form') ?> |</span><span class="purple-text" style=" color: #7467f0; "> <?= get_phrase('Documentation/Certification') ?></span></h6>
        </div>
        <div class="col-md-5" style="text-align: right;">
            <form action="<?php echo site_url('user/student_materials/add'); ?>" enctype="multipart/form-data" method="post">
                <div class="btn-group" role="group">
                    <a type="button" class="btn btn-secondary waves-effect waves-light" href="javascript:history.go(-1)"><?= get_phrase('Back to Application Form') ?></a>
                    <button type="submit" class="btn btn-primary waves-effect waves-light"><?= get_phrase('Save Upload') ?></button>
                </div>

        </div>
    </div>
    <br>
    <!-- Content -------------------------------------------------------------------------------------------------------------------------------------------------->
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <div id="account-details" class="content">
                        <div class="content-header mb-3">
                            <h5 class="mb-0"><?= get_phrase('Applicant Information') ?></h5>
                        </div>
                        <hr>
                        <!--load content -->
                        <?php foreach ($students->result_array() as $key => $student) : ?>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('Application ID') ?>:
                                </div>
                                <div class="col-md-4 answer">
                                    <?php echo $student['app_id']; ?><input type="hidden" id="sid" name="app_id" value="<?php echo $student['app_id']; ?>">
                                </div>
                                <div class="col-md-2"><?= get_phrase('Student ID') ?>:
                                </div>
                                <div class="col-md-4 answer">
                                    <?php echo $student['id']; ?><input type="hidden" name="sid" value="<?php echo $student['id']; ?>">
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('Applicant Name') ?>:
                                </div>
                                <div class="col-md-4 answer">
                                    <?php echo $student['kanji_fn']; ?><input type="hidden" name="kanji_fn" value="<?php echo $student['kanji_fn']; ?>">
                                </div>
                                <div class="col-md-2"><?= get_phrase('Where to Apply') ?>:
                                </div>
                                <div class="col-md-4 answer">
                                    <?php echo $student['institute_name']; ?><input type="hidden" name="applicationplace" value="<?php echo $student['institute_name']; ?>">
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('Date') ?>:
                                </div>
                                <div class="col-md-4 answer">
                                    <?php echo $student['created_at']; ?><input type="hidden" name="created_at" value="<?php echo $student['created_at']; ?>">
                                </div>
                                <div class="col-md-6">
                                </div>
                            </div>
                            <!-- File Uploader ----------------------------------------------------------------------------------------------------------------->
                    </div>
                </div>
            </div>
        </div>
    </div>
 <br>
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <div id="account-details" class="content">
                        <div class="content-header mb-3">
                            <h5 class="mb-0"><?= get_phrase('Upload Documentation/Certification') ?></h5>
                            <p>(<?= get_phrase('upload_content') ?>)</p>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Document Type') ?>:
                            </div>
                            <div class="col-md-10 answer">
                                <select class="form-select border mandatory" id="materialDropdown" name="material_type" aria-label="materialDropdown" required>
                                    <option><?= get_phrase('Select Document Type') ?></option>
                                    <option value="doc1"><?= get_phrase('Application for Admission') ?></option>
                                    <option value="doc2"><?= get_phrase('Resume') ?></option>
                                    <option value="doc3"><?= get_phrase('Statement of Purpose') ?></option>
                                    <option value="doc4"><?= get_phrase('Document for Sponsorship') ?></option>
                                    <option value="doc5"><?= get_phrase('List of Family Members of the Sponsor') ?></option>
                                    <option value="doc6"><?= get_phrase('Graduation Certificate of the Latest Education') ?></option>
                                    <option value="doc7"><?= get_phrase('Enrollment Certificate') ?></option>
                                    <option value="doc8"><?= get_phrase('Transcript of the Latest Education') ?></option>
                                    <option value="doc9"><?= get_phrase('Certificate of JP Learning from JP School') ?></option>
                                    <option value="doc10"><?= get_phrase('Pass Certificate of JP Language Test') ?></option>
                                    <option value="doc11"><?= get_phrase('Copy of Passport (Applicant)') ?></option>
                                    <option value="doc12"><?= get_phrase('Copy of  ID card (Applicant)') ?></option>
                                    <option value="doc13"><?= get_phrase('Birth Certificate (Applicant)') ?></option>
                                    <option value="doc14"><?= get_phrase('Certificate of Relationship') ?></option>
                                    <option value="doc15"><?= get_phrase('Copy of  ID card (Sponsor)') ?></option>
                                    <option value="doc16"><?= get_phrase('Deposit Balance Certificate(Sponsor)') ?></option>
                                    <option value="doc17"><?= get_phrase('Certificate of occupation (Sponsor)') ?></option>
                                    <option value="doc18"><?= get_phrase('Copy of Bank Book') ?></option>
                                    <option value="doc19"><?= get_phrase('Income Certificate （Sponsor/3yaers）(Sponsor)') ?></option>
                                    <option value="doc20"><?= get_phrase('Tax Certificate （Sponsor/3yaers）(Sponsor)') ?></option>
                                    <option value="doc21"><?= get_phrase('Certificate of Incumbency (Applicant)') ?></option>
                                    <option value="doc22"><?= get_phrase('Certificate of  Residence or substitute for address verification (Applicant)') ?></option>
                                    <option value="doc23"><?= get_phrase('Certificate of  Residence or substitute documents (Sponsor)') ?></option>
                                    <option value="doc24"><?= get_phrase('Reason of  Re-apply') ?></option>
                                    <option value="doc25"><?= get_phrase('Explanation of the Asset Formation Process (if needed/3years)') ?></option>
                                    <option value="doc26"><?= get_phrase('Business License (in case of individual business owner)') ?></option>

                                </select>
                                <script type="text/javascript">
                                    var elem = document.getElementById("materialDropdown");
                                    elem.onchange = function(){
                                        var hiddenDiv = document.getElementById("showMe");
                                        hiddenDiv.style.display = (this.value == "doc1") ? "block":"none";
                                        var hiddenDiv = document.getElementById("Purpose");
                                        hiddenDiv.style.display = (this.value == "doc3") ? "block":"none";
                                        var hiddenDiv = document.getElementById("doc4");
                                        hiddenDiv.style.display = (this.value == "doc4") ? "block":"none";
                                        var hiddenDiv = document.getElementById("doc5");
                                        hiddenDiv.style.display = (this.value == "doc5") ? "block":"none";
                                        var hiddenDiv = document.getElementById("doc11");
                                        hiddenDiv.style.display = (this.value == "doc11") ? "block":"none";
                                        var hiddenDiv = document.getElementById("doc18");
                                        hiddenDiv.style.display = (this.value == "doc18") ? "block":"none";
                                        var hiddenDiv = document.getElementById("doc22");
                                        hiddenDiv.style.display = (this.value == "doc22") ? "block":"none";
                                    };
                                </script><br>
                                <div id="showMe" class="alert alert-warning " role="alert" style="display: none;"><?= get_phrase('Note') ?>:<?= get_phrase('Please use the format provided') ?>. </div>
                                <div id="doc4" class="alert alert-warning " role="alert" style="display: none;"><?= get_phrase('Note') ?>:<?= get_phrase('Please use the format provided') ?>. </div>
                                <div id="doc5" class="alert alert-warning " role="alert" style="display: none;"><?= get_phrase('Note') ?>:<?= get_phrase('Please use the format provided') ?>. </div>
                                <div id="doc11" class="alert alert-warning " role="alert" style="display: none;"><?= get_phrase('Note') ?>:<?= get_phrase('If the applicant have visited to Japan, a copy of Immigration Stamp is required.') ?>. </div>
                                <div id="doc18" class="alert alert-warning " role="alert" style="display: none;"><?= get_phrase('Note') ?>:<?= get_phrase('Please do not omit any bank records from translation.') ?>. </div>
                                <div id="doc22" class="alert alert-warning " role="alert" style="display: none;"><?= get_phrase('Note') ?>:<?= get_phrase('Required if the parmanent address and current address are different.') ?>. </div>
                                <div id="Purpose" class="alert alert-warning " role="alert" style="display: none;"><?= get_phrase('Note') ?>:<?= get_phrase('Please use the format provided') ?>.
                                <?= get_phrase('Please specify the reason') ?>
                                <ol>
                                        <li><?= get_phrase('Why you want to study abroad') ?></li>
                                        <li><?= get_phrase('Your career(If you don not have career more than 3 years from the latest education, please specify the reason.)') ?></li>
                                        <li><?= get_phrase('Why you want to enter to our school') ?></li>
                                        <li><?= get_phrase('The career after graduate from our school') ?></li>
                                        <li><?= get_phrase('The career after you study in Japan') ?></li>
                                    </ol>
                                </div>
                            </div>

                        </div>
                        
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Folder No.') ?>:
                            </div>

                            <!-- Checkbox column -->
                            <div class="col-md-5">
                            <input type="radio" id="original" name="document_type" value="original" required />
                            <label for="original"><?= get_phrase('Original letter') ?></label>
                                
                            </div>
                            <!-- Checkbox column -->
                            <div class="col-md-5">
                            <input type="radio" id="translated" name="document_type" value="translated" required />
                             <label for="translated"><?= get_phrase('Translated') ?> </label>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-2">
                                <?= get_phrase('Upload Document') ?>:
                            </div>
                            <div class="col-md-10">
                                <input class="form-control mandatory" type="file" id="formFile" name="material" required />
                            </div>
                           
                        </div>
                        <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">

                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <div id="account-details" class="content">
                        <div class="content-header mb-3">
                            <h5 class="mb-0"><?= get_phrase('Documents check list for immigration application') ?></h5>
                        </div>
                        <hr>

<!-- load document list -->
<table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th></th>
                                                            <th><?= get_phrase('Documentation/Certification Type') ?></th>
                                                            <th><?= get_phrase('Folder No.') ?></th>
                                                            <th><?= get_phrase('Last Updated Date') ?></th>
                                                            <th><?= get_phrase('Documentation/Certification Status') ?></th>
                                                            <th style="width: 13%;"><?= get_phrase('Action') ?></th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <?php foreach ($materials as $row) : ?>  
                                                            <tr>
                                                                <td>  
                                                                <!-- Load icon based on status  -->
                                                                <?php If ($row['status'] == "1"){   ?>
                                                                     <a href="/uploads/student_immigration_documents/<?php echo $row['file']; ?>" target="_blank"> <img src="/assets/img/pdf.png" alt="<?php echo $row['file']; ?>" style="width: 30px;" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="<?= get_phrase('Document Uploaded') ?>" ></a>
                                                               <?php  } elseif ($row['status'] == "2"){   ?>
                                                                    <a href="/uploads/student_immigration_documents/<?php echo $row['file']; ?>" target="_blank"> <img src="/assets/img/checked.png" alt="<?php echo $row['file']; ?>" style="width: 30px;" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="<?= get_phrase('Chacked') ?>" ></a>
                                                                <?php } elseif ($row['status'] == "3"){   ?>
                                                                    <a href="/uploads/student_immigration_documents/<?php echo $row['file']; ?>" target="_blank"> <img src="/assets/img/Waiting.png" alt="<?php echo $row['file']; ?>" style="width: 30px;" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="<?= get_phrase('Waiting for corrections') ?>" ></a>
                                                                <?php } elseif ($row['status'] == "4"){   ?>
                                                                    <a href="/uploads/student_immigration_documents/<?php echo $row['file']; ?>" target="_blank"> <img src="/assets/img/PDF-check.png" alt="<?php echo $row['file']; ?>" style="width: 30px;" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="<?= get_phrase('Completed') ?>" ></a>
                                                                <?php } ?>
                                                                </td>
                                                                <td>
                                                                <?php If ($row['type'] == "doc1"){    
                                                                     echo get_phrase('Application for Admission');
                                                                } elseif ($row['type'] == "doc2"){    
                                                                    echo get_phrase('Resume');
                                                                } elseif ($row['type'] == "doc3"){    
                                                                    echo get_phrase('Statement of Purpose');
                                                                } elseif ($row['type'] == "doc4"){    
                                                                    echo get_phrase('Document for Sponsorship');
                                                                } elseif ($row['type'] == "doc5"){    
                                                                    echo get_phrase('List of Family Members of the Sponsor');
                                                                } elseif ($row['type'] == "doc6"){    
                                                                    echo get_phrase('Graduation Certificate of the Latest Education');
                                                                } elseif ($row['type'] == "doc7"){    
                                                                    echo get_phrase('Enrollment Certificate');
                                                                } elseif ($row['type'] == "doc8"){    
                                                                    echo get_phrase('Transcript of the Latest Education');
                                                                } elseif ($row['type'] == "doc9"){    
                                                                    echo get_phrase('Certificate of JP Learning from JP School');
                                                                } elseif ($row['type'] == "doc10"){    
                                                                    echo get_phrase('Pass Certificate of JP Language Test');
                                                                } elseif ($row['type'] == "doc11"){    
                                                                    echo get_phrase('Copy of Passport (Applicant)');
                                                                } elseif ($row['type'] == "doc12"){    
                                                                    echo get_phrase('Copy of  ID card (Applicant)');
                                                                } elseif ($row['type'] == "doc13"){    
                                                                    echo get_phrase('Birth Certificate (Applicant)');
                                                                } elseif ($row['type'] == "doc14"){    
                                                                    echo get_phrase('Certificate of Relationship');
                                                                } elseif ($row['type'] == "doc15"){    
                                                                    echo get_phrase('Copy of  ID card (Sponsor)');
                                                                } elseif ($row['type'] == "doc16"){    
                                                                    echo get_phrase('Deposit Balance Certificate(Sponsor)');
                                                                } elseif ($row['type'] == "doc17"){    
                                                                    echo get_phrase('Certificate of occupation (Sponsor)');
                                                                } elseif ($row['type'] == "doc18"){    
                                                                    echo get_phrase('Copy of Bank Book');
                                                                } elseif ($row['type'] == "doc19"){    
                                                                    echo get_phrase('Income Certificate （Sponsor/3yaers）(Sponsor)');
                                                                } elseif ($row['type'] == "doc20"){    
                                                                    echo get_phrase('Tax Certificate （Sponsor/3yaers）(Sponsor)');
                                                                } elseif ($row['type'] == "doc21"){    
                                                                    echo get_phrase('Certificate of Incumbency (Applicant)');
                                                                } elseif ($row['type'] == "doc22"){    
                                                                    echo get_phrase('Certificate of  Residence or substitute for address verification (Applicant)');
                                                                } elseif ($row['type'] == "doc23"){    
                                                                    echo get_phrase('Certificate of  Residence or substitute documents (Sponsor)');
                                                                } elseif ($row['type'] == "doc24"){    
                                                                    echo get_phrase('Reason of  Re-apply');
                                                                } elseif ($row['type'] == "doc25"){    
                                                                    echo get_phrase('Explanation of the Asset Formation Process (if needed/3years)');
                                                                } elseif ($row['type'] == "doc26"){    
                                                                    echo get_phrase('Business License (in case of individual business owner)');
                                                                }  
    
                                                                ?></td>
                                                              
                                                                <td><?php If ($row['document_type'] == "original"){
                                                                   echo get_phrase('Original letter');
                                                                } elseif  ($row['document_type'] == "translated"){
                                                                    echo get_phrase('Translated');
                                                                } 
                                                                ?></td>
                                                                <td><?php echo $row['created_at']; ?></td>
                                                                <td> 
                                                                     <!-- Load status  -->
                                                                <?php If ($row['status'] == "1"){  
                                                                    echo get_phrase('Document Uploaded') ;
                                                                 } elseif ($row['status'] == "2"){   
                                                                    echo get_phrase('Chacked') ;
                                                                } elseif ($row['status'] == "3"){   
                                                                    echo get_phrase('Waiting for corrections');
                                                                } elseif ($row['status'] == "4"){  
                                                                    echo get_phrase('Completed') ;
                                                                 } ?>
                                                                <a href="/uploads/student_immigration_documents/<?php echo $row['file']; ?>" target="_blank" style="display: none;"> <img src="/assets/img/comment.png" alt="<?php echo $row['file']; ?>" style="width: 30px;" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="<?= get_phrase('Comment reserved from Domesitc User') ?>" ></a>
                                                               
                                                            </td>
                                                                <td style="width:10">
                                                                <a href="/uploads/student_immigration_documents/<?php echo $row['file']; ?>"  target="_blank" >
                                                                        <span><i class="menu-icon tf-icons ti ti-eye" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="<?= get_phrase('View') ?>" ></i></span></a>
                                                                    <a href="javascript:;" data-bs-target="#editSlide<?php echo $row['id']; ?>" data-bs-toggle="modal">
                                                                        <span><i class="menu-icon tf-icons ti ti-upload" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="<?= get_phrase('Re-Upload') ?>" ></i></span></a>
                                                                    <a href="javascript:;" data-bs-target="#deleteSlide<?php echo $row['id']; ?>" data-bs-toggle="modal">
                                                                        <span><i class="menu-icon tf-icons ti ti-trash"></i></span></a>
                                                                </td>                                        
                                                            </tr>


                                                            <!-- Modals -->

                                                            <!-- Edit Rule Modal -->
                                                            <!-- Edit Rule Modal -->
                                                            <div class="modal fade" id="editSlide<?php echo $row['id']; ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                            <div class="modal-content p-3 p-md-5">
                                                <div class="modal-body">
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    <div class="mb-4">
                                                    <div class="content-header mb-3">
                            <h5 class="mb-0"><?= get_phrase('Re-Upload') ?> <?= get_phrase('documentation/certification') ?></h5>
                        </div>
                        <hr>
                                                        <form action="<?php echo site_url('user/student_materials/update_document'); ?>" enctype="multipart/form-data" method="post">
                                                            <div class="row">
                                                                <div class="col-md-3">
                                                                    <?= get_phrase('Upload Document') ?>:
                                                                </div>
                                                                <div class="col-md-9">
                                                                    <input class="form-control mandatory" type="file" id="formFile" name="material" required />
                                                                </div>
                                                            </div>
                                                            <input type="hidden" name="material_id" value="<?php echo $row['id']; ?>">
                                                            <input type="hidden" name="material_type" value="<?php echo $row['material_type']; ?>">
                                                            <input type="hidden" name="app_id" value="<?php echo $row['app_id']; ?>">
                                                            <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                                                            
                                                            <br>
                                                            <div  class="alert alert-info " role="alert"> 
                                                            <p><i class="menu-icon tf-icons ti ti-star" ></i><?= get_phrase('Please note once you re-uploaded a document the status will be reset.') ?></p>
                                                             </div>
                                                             <br>
                                                             <div class="row">
                                                                <button type="submit" class="btn btn-primary waves-effect waves-light"><?= get_phrase('Save Upload') ?></button>
                                                            </div>
                                                        </form>
                                                        <p><?php echo $row['material']; ?></p>
                                                    </div>
                                                    <!-- Display any other content you want -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                                        <!-- Delete Rule Modal -->
                                                        <div class="modal fade" id="deleteSlide<?php echo $row['id']; ?>" tabindex="-1" aria-hidden="true">
                                                            <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                                                <div class="modal-content p-3 p-md-5">
                                                                    <div class="modal-body">
                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                        <div class="text-center mb-4">
                                                                            <h3 class="mb-2" style="color : #7367f0">Are you sure?</h3>  
                                                                            <p>Do You Want To Remove This Material ?</p>
                                                                        </div>
                                                                        <div class="text-center mb-4">
                                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                                                                            <a href="javascript:;" class="btn btn-danger" onclick="deleteMaterial(<?php echo $row['id']; ?>)">Yes</a>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>    
                                                        
                                                        
                                                    <?php endforeach; ?> 

                                                    </tbody>
                                                </table>
                                                
                        
                </div></div>  </div></div>  </div> 
<?php endforeach; ?>
</div>