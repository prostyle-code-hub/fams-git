<ul class="menu-inner py-1">
    <!-- Dashboards -->
    <li class="menu-item <?php
    if ($tag == 'dashboard') {
        echo "active open";
    }
    ?>">
        <a href="<?php echo base_url() ?>" class="menu-link">
            <i class="menu-icon tf-icons ti ti-home"></i>
            <div><?= get_phrase('dashboard'); ?></div>    
        </a>        
    </li>

    <?php if ($this->session->userdata('role_id') == 1 || $this->session->userdata('role_id') == 2) { ?>
        <li class="menu-item <?php
        if ($tag == 'stuff_info' || $tag == 'school_rule') {
            echo "open";
        }
        ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-color-swatch"></i>
                <div><?= get_phrase('school_stuff') ?></div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'stuff_info') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/stuff_information'); ?>" class="menu-link">
                        <div><?= get_phrase('stuff_info') ?></div>
                    </a>
                </li>
                <li class="menu-item <?php
                if ($tag == 'school_rule') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/school_rule'); ?>" class="menu-link">
                        <div><?= get_phrase('school_rule') ?></div>
                    </a>               
                </li>

            </ul>
        </li>
    <?php } ?>

    <?php if ($this->session->userdata('role_id') == 1 || $this->session->userdata('role_id') == 2) { ?>
        <li class="menu-item <?php
        if ($tag == 'agent_list') {
            echo "open";
        }
        ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-users"></i>
                <div><?= get_phrase('agent') ?></div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'agent_list') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/agents'); ?>" class="menu-link">
                        <div><?= get_phrase('agent_list') ?></div>
                    </a>
                </li>                           
            </ul>
        </li>
    <?php } ?>
    <?php if ($this->session->userdata('role_id') == 1 || $this->session->userdata('role_id') == 2) { ?>
        <li class="menu-item <?php
        if ($tag == 'domestic_list' || $tag == 'domestic_add') {
            echo "open";
        }
        ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-users"></i>
                <div><?= get_phrase('domestic_user') ?></div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'domestic_list') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/domestic'); ?>" class="menu-link">
                        <div><?= get_phrase('domestic_user_list') ?></div>
                    </a>

                </li>
                <li class="menu-item <?php
                if ($tag == 'domestic_add') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/domestic/add'); ?>" class="menu-link">
                        <div><?= get_phrase('new_domestic_user') ?></div>
                    </a>               
                </li>            
            </ul>
        </li>
    <?php } ?>

    <?php if ($this->session->userdata('role_id') == 1 || $this->session->userdata('role_id') == 2) { ?>
        <li class="menu-item <?php
        if ($tag == 'list_of_application' || $tag == 'search_application_domestic') {
            echo "open";
        }
        ?>" >
            <a href="javascript:void(0);" class="menu-link menu-toggle" >
                <i class="menu-icon tf-icons ti ti-brand-firebase"></i>
                <div><?= get_phrase('Applicant') ?></div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'list_of_application') {
                    echo "active open";
                }
                ?>">         
                    <a href="<?php echo site_url('user/student_application_domestic/'); ?>" class="menu-link">
                        <div><?= get_phrase('List of Applicant') ?></div>
                    </a>
                </li>                   
            </ul>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'search_application_domestic') {
                    echo "active open";
                }
                ?>"">
                    <a href="<?php echo site_url('user/search_application_domestic/'); ?>" class="menu-link">
                        <div><?= get_phrase('Search Applicant') ?></div>
                    </a>
                </li>                   
            </ul>
        </li>  
    <?php } ?>





    <?php if ($this->session->userdata('role_id') == 3) { ?>        
        <li class="menu-item <?php
        if ($tag == 'school_rule_read') {
            echo "open";
        }
        ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle" >
                <i class="menu-icon tf-icons ti ti-pencil"></i>
                <div><?= get_phrase('learn_before_use') ?></div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'school_rule_read') {
                    echo "active open";
                }
                ?>">                
                    <a href="<?php echo site_url('user/school_rules'); ?>" class="menu-link">
                        <div><?= get_phrase('school_rule') ?></div>
                    </a>
                </li>                   
            </ul>            
        </li>
    <?php } ?>

    <?php if (($this->session->userdata('role_id') == 3) && ( $this->session->userdata('rule_pass') == '1')) { ?>
        <?php //echo "Value".$x;    ?>
        <li class="menu-item <?php
        if (($tag == 'student_add') || ($tag == 'student_search') || ($tag == 'student_list')) {
            echo "open";
        }
        ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-man"></i>
                <div><?= get_phrase('Applicant') ?></div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'student_add') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/student/add'); ?>" class="menu-link">
                        <div><?= get_phrase('Registration of Applicant') ?></div>
                    </a>
                </li>                   
            </ul>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'student_list') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/student'); ?>" class="menu-link">
                        <div><?= get_phrase('Applicant List') ?></div>
                    </a>
                </li>                   
            </ul>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'student_search') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/student/search'); ?>" class="menu-link">
                        <div><?= get_phrase('Search Applicant') ?></div>
                    </a>
                </li>                   
            </ul>
        </li>
    <?php } ?>

<?php if ($this->session->userdata('role_id') == 3) { ?>
        <li class="menu-item">
            <a href="/user/manage_profile_agent/" class="menu-link" id="myprofile">
                <i class="menu-icon tf-icons ti ti-users"></i>
                <div><?= get_phrase('agent_info') ?></div>
            </a>
        </li>
    <?php } ?>

<?php if ($this->session->userdata('role_id') == 3) { ?>

        <li class="menu-item <?php
        if ($tag == 'student_application_new' || $tag == 'applicant_search' || $tag == 'student_application_list') {
            echo "open";
        }
        ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle" >
                <i class="menu-icon tf-icons ti ti-file"></i>
                <div><?= get_phrase('Application Form') ?></div>
            </a>
           <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'student_application_new') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/create_new_student_application/'); ?>" class="menu-link">
                        <div><?= get_phrase('New Application Form') ?></div>
                    </a>
                </li>                   
            </ul>
           <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'student_application_list') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/student_application/'); ?>" class="menu-link">
                        <div><?= get_phrase('Applicatio Form List') ?></div>
                    </a>
                </li>                   
            </ul>
            <ul class="menu-sub">
                <li class="menu-item <?php
                if ($tag == 'applicant_search') {
                    echo "active open";
                }
                ?>">
                    <a href="<?php echo site_url('user/search_application/'); ?>" class="menu-link">
                        <div><?= get_phrase('Search Application Forms') ?></div>
                    </a>
                </li>                   
            </ul>
        </li>
    <?php } ?>

<?php if ($this->session->userdata('role_id') == 3) { ?>
        <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-report"></i>
                <div><?= get_phrase('report') ?></div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="app-user-list.html" class="menu-link">
                        <div><?= get_phrase('application_status') ?></div>
                    </a>
                </li>                   
            </ul>

        </li>
    <?php } ?>

<?php if ($this->session->userdata('role_id') == 3) { ?>
        <li class="menu-item">
            <a href="#l" class="menu-link">
                <i class="menu-icon tf-icons ti ti-phone"></i>
                <div><?= get_phrase('call_user') ?></div>
            </a>
        </li>
<?php } ?>

</ul>