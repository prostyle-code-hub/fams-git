<span style="background-color: #5949fe;color: #ffffff;font-size: x-small;">UI No: FAMS2100</span> <!-- UI Number -->
<link rel="stylesheet" href="<?php echo base_url('assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.css'); ?>" />
<link rel="stylesheet" href="<?php echo base_url('assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.css'); ?>" />
<script type="text/javascript">
    document.getElementById('student_page').style = 'background-color: #7467f0;color: white;';
</script>
<script type="text/javascript">
    function addDashes(f)
    {
        f.value = f.value.slice(0, 3) + "-" + f.value.slice(3, 6) + "-" + f.value.slice(6, 10);
    }
</script>

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-md-3">
            <h6 class="fw-bold py-3 ms-4"><span><?= get_phrase('student-information') ?> |</span><span class="purple-text" style=" color: #7467f0; "> <?= get_phrase('registration') ?></span></h6>
        </div>
        <div class="col-md-9" style="text-align: right;">
            <form action="<?php echo site_url('user/student/create_student'); ?>" enctype="multipart/form-data" method="post">
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-secondary waves-effect waves-light" disabled><?= get_phrase('View') ?></button>
                    <button type="button" class="btn btn-secondary waves-effect waves-light" disabled><?= get_phrase('Modify') ?></button>
                    <a type="button" class="btn btn-secondary waves-effect waves-light" href="/user/student/"><?= get_phrase('Back') ?></a>
                    <button type="reset" class="btn btn-secondary waves-effect waves-light"><?php echo get_phrase('Clear'); ?></button>
                    <button type="submit" class="btn btn-primary waves-effect waves-light"><?= get_phrase('Save') ?></button>
                </div>

        </div>
    </div>
    <div class="row">
        <div class="col-xl-12">

            <div class="card">
                <div class="card-body">
                    <div id="account-details" class="content">
                        <div class="content-header mb-3">
                            <h5 class="mb-0"><?= get_phrase('Basic Information') ?></h5>
                        </div>
                        <hr>
                        <!--load content -->
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('First ＆ Middle Name') ?>:<br>
                                <smal style="font-size: x-small;color: #7467f0;">(<?= get_phrase('kanji, Alphabet') ?>) </smal>
                            </div>
                            <div class="col-md-4 answer"><input type="text" class="ms-1 form-control form-input1 mandatory" aria-label="First & Middle name" id="kanji_fname" name="kanji_fname" placeholder="<?= get_phrase('First ＆ Middle Name') ?>" required>
                            </div>
                            <div class="col-md-2"><?= get_phrase('Last Name') ?>:<br>
                                <smal style="font-size: x-small;color: #7467f0;">(<?= get_phrase('kanji, Alphabet') ?>) </smal>
                            </div>
                            <div class="col-md-4 answer"><input type="text" class="ms-1 form-control form-input1 mandatory" aria-label="Last name" placeholder="<?= get_phrase('Last Name') ?>" id="kanji_lname" name="kanji_lname" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('First ＆ Middle Name') ?>:<br>
                                <smal style="font-size: x-small;color: #7467f0;">(<?= get_phrase('Romaji') ?>) </smal>
                            </div>
                            <div class="col-md-4 answer">
                                <input type="text" class="ms-1 form-control form-input1 mandatory" aria-label="First & Middle name" id="romaji_fname" name="romaji_fname" placeholder="<?= get_phrase('First ＆ Middle Name') ?>" required>
                            </div>
                            <div class="col-md-2"><?= get_phrase('Last Name') ?>:<br>
                                <smal style="font-size: x-small;color: #7467f0;">(<?= get_phrase('Romaji') ?>) </smal>
                            </div>
                            <div class="col-md-4 answer">
                                <input type="text" class="ms-1 form-control form-input1 mandatory" id="romajii_lname" name="romajii_lname" aria-label="Last name" placeholder="<?= get_phrase('Last Name') ?>" required>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Sex') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="radio" id="option1" name="gender" value="Male" onclick="document.getElementById('stu_photo').src = '<?php echo base_url('assets/img/male.png'); ?>'">
                                <label for="option1" class="me-5"><?= get_phrase('Male') ?></label>
                                <input type="radio" id="option1" name="gender" value="Female" onclick="document.getElementById('stu_photo').src = '<?php echo base_url('assets/img/famale.png'); ?>'">
                                <label for="option1" class="me-5"><?= get_phrase('Female') ?></label>
                            </div>
                            <div class="col-md-2"><?= get_phrase('Date of Birth') ?>:
                            </div>
                            <div class="col-md-4 answer">
                                <input type="date" id="dob" class="form-control flatpickr-input mandatory" name="dob"  required/>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('spouse') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="radio" id="spouse1" name="spouse" value="With spouse" >
                                <label for="spouse1" class="me-5"><?= get_phrase('With spouse') ?></label>
                                <input type="radio" id="spouse1" name="spouse" value="Without spouse">
                                <label for="spouse1" class="me-5"><?= get_phrase('Without spouse') ?></label>                              
                            </div>
                            <div class="col-md-2">
                            </div>
                            <div class="col-md-4 answer">

                            </div>
                        </div>
                        <br>

                        <div class="row" id="sopuce-on">
                            <div class="col-md-2"><?= get_phrase('First ＆ Middle Name') ?>:
                                <br>
                                <smal style="font-size: x-small;color: #7467f0;"><?= get_phrase('of Spouse') ?> </smal>
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" class="ms-1 form-control form-input1" aria-label="<?= get_phrase('First ＆ Middle Name of Spouse') ?>" placeholder="<?= get_phrase('First ＆ Middle Name of Spouse') ?>" name="first_middle_name_spouse">
                            </div>
                            <div class="col-md-2"><?= get_phrase('Last Name ') ?>:
                                <br>
                                <smal style="font-size: x-small;color: #7467f0;"><?= get_phrase('of Spouse') ?> </smal>
                            </div>
                            <div class="col-md-4 answer">
                                <input type="text" class="ms-1 form-control form-input1" aria-label="<?= get_phrase('Last Name of Spouse') ?>" placeholder="<?= get_phrase('Last Name of Spouse') ?>" name="last_name_spouse" >
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Birthplace Country') ?>:</div>
                            <div class="col-md-4 form-check ">
                                <select name="birth_country" id="birthcountry" class="ms-1 form-control form-input1 mandatory" required >
                                    <option value='' ><?= get_phrase('Select Country') ?></option>
                                    <?php
                                    $bithcountry = ['country' => 'Select Country'];
                                    $countryList = ["Nepal", "India", "Sri Lanka", "Vietnam", "Japan", "Bangladesh", "Myanmar", "Mongolia", "Indonesia", "China", "Peru", "Philippines", "Thailand", "Iran", "Uzbekistan"];

                                    foreach ($countryList as $country) {
                                        $sel = ($bithcountry['country'] === $country) ? 'selected' : '';
                                        echo "<option value='$country' $sel> "
                                        ?> 
                                        <?= get_phrase($country) ?> 
                                        <?=
                                        "</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-2"><?= get_phrase('Prefecture (Region)') ?>:</div>
                            <div class="col-md-4 answer">
                                <input type="text" class="ms-1 form-control form-input1 mandatory" aria-label="<?= get_phrase('Prefecture (Region)') ?>" placeholder="<?= get_phrase('Region') ?>" id="passport_number" name="passport_number" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Birthplace') ?>:
                            </div>
                            <div class="col-md-10 form-check">
                                <textarea class="ms-1 form-control form-input1 two-div mandatory" name="permanent_address" id="permanent_address" rows="3" placeholder="<?= get_phrase('Permanent Address') ?>" required></textarea>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Country of Citizenship') ?>:</div>
                            <div class="col-md-4 form-check ">
                                <select name="citizenship" id="citizenship" class="ms-1 form-control form-input1 mandatory" required >
                                    <option value='' ><?= get_phrase('Select Country') ?></option>
                                    <?php
                                    $citizenship = ['country' => 'Select Country'];

                                    foreach ($countryList as $country) {
                                        echo "<option value='$country' $sel> "
                                        ?> 
                                        <?= get_phrase($country) ?> 
                                        <?=
                                        "</option>";
                                    }
                                    ?>
                                </select>

                            </div>
                            <div class="col-md-2"><?= get_phrase('Occupation') ?>:
                            </div>
                            <div class="col-md-4 answer">
                                <input type="text" class="ms-1 form-control form-input1 mandatory" aria-label="<?= get_phrase('Occupation') ?>" placeholder="<?= get_phrase('Occupation') ?>" id="kanji_lname" name="occupation" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Passport Number') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" class="ms-1 form-control form-input1 mandatory" aria-label="<?= get_phrase('Passport Number') ?>" placeholder="<?= get_phrase('Passport Number') ?>" id="passport_number" name="passport_number" required>
                            </div>
                            <div class="col-md-2"><?= get_phrase('Passport issue Date') ?>:
                            </div>
                            <div class="col-md-4 answer">
                                <input type="date" id="username" name="passport_create" class="ms-1 form-control form-input1 mandatory" placeholder="<?= get_phrase('Passport issue Date') ?>" required/>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Passport Expiry Date') ?>:
                            </div>
                            <div class="col-md-4 form-check">
                                <input type="date" id="username" name="passport_exp" class="ms-1 form-control form-input1 mandatory" placeholder="<?= get_phrase('Passport Expiry Date') ?>" required/>
                            </div>
                            <div class="col-md-2"><?= get_phrase('Future Plans') ?>: </div>

                            <div class="col-md-4 answer ">
                                <select name="future_plan" id="future_plan" class="ms-1 form-control form-input1 mandatory" required>
                                    <option value=""><?= get_phrase('Select Future Plan') ?></option>
                                    <option value="Universities"><?= get_phrase('University') ?></option>
                                    <option value="Vocational schools"><?= get_phrase('Vocational school') ?></option>
                                    <option value="Employment"><?= get_phrase('Employment') ?></option>
                                </select>
                            </div>                        

                        </div>
                        <div class="row">

                            <div class="col-md-2"><?= get_phrase('Future Plans details') ?><br><small>(<?= get_phrase('School Name') ?>, <?= get_phrase('Company Name') ?>)</small>: </div>
                            <div class="col-md-10 form-check ">
                                <textarea class="form-control " name="future_plan_detail" id="" rows="3"></textarea>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <br><br>
            <div class="card">
                <div class="card-body">
                    <div id="account-details" class="content">
                        <div class="content-header mb-3">
                            <h5 class="mb-0"><?= get_phrase('Contact in Home') ?></h5>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('current_address') ?>:
                            </div>
                            <div class="col-md-10 form-check ">
                                <textarea class="form-control mandatory" name="current_address" id="" rows="3" placeholder="" required></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('contact_ap_fixed') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="number" id="romaji_fname"  name="contact_ap_fixed" class="form-control mandatory" required maxlength="10" maxlength="10"/>
                            </div>
                            <div class="col-md-2"><?= get_phrase('contact_ap_mobile') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="number" id="romajii_lname"  name="contact_ap_mobile" class="form-control" maxlength="10" maxlength="10" />
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('contact_ap_mail') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="email" id="romaji_fname" name="contact_ap_mail" class="form-control" />
                            </div>
                            <div class="col-md-2"><?= get_phrase('contact_ap_fax') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="romajii_lname"   name="contact_ap_fax" class="form-control" maxlength="10"/>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <br><br>
            <div class="card">
                <div class="card-body">
                    <!-- Family Records -->
                    <div id="account-details" class="content">
                        <div class="content-header mb-3">
                            <h5 class="mb-0"><?= get_phrase('Family Information') ?></h5>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('relationship') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <select name="family_relationship_1"  id="family_relationship" class="form-control">   
                                    <option value="" style="color: #7467f0;"><?= get_phrase('Select the relationship') ?></option>
                                    <option value="Father"><?= get_phrase('Father') ?></option>
                                    <option value="Mother"><?= get_phrase('Mother') ?></option>
                                    <option value="Grand mother"><?= get_phrase('Grand Mother') ?></option>
                                    <option value="Grand Father"><?= get_phrase('Grand Father') ?></option>
                                    <option value="Elder Brother"><?= get_phrase('Elder Brother') ?></option>
                                    <option value="Younger Brother"><?= get_phrase('Younger Brother') ?></option>
                                    <option value="Elder Sister"><?= get_phrase('Elder Sister') ?></option>
                                    <option value="Younger Sister"><?= get_phrase('Younger Sister') ?></option>
                                </select>
                            </div>
                            <div class="col-md-2"><?= get_phrase('first_name_and_last_name') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="kanji_lname" name="family_first_and_lastname_1" class="form-control" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('date_of_birth') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="date" id="kanji_fname" name="family_dob_1" class="form-control" />
                            </div>
                            <div class="col-md-2"><?= get_phrase('Profession') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="kanji_lname" name="family_profession_1" class="form-control" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('current_address_family') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <textarea class="form-control" name="family_current_address_1" id="" rows="3"></textarea>
                            </div>
                            <div class="col-md-2"><?= get_phrase('life_and_death') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="radio" id="family_life_and_death1" name="family_life_and_death_1" value="Life">
                                <label for="family_life_and_death1" class="me-5"><?= get_phrase('Life') ?></label>
                                <input type="radio" id="family_life_and_death1" name="family_life_and_death_1" value="Death">
                                <label for="family_life_and_death1" class="me-5"><?= get_phrase('Death') ?></label>
                            </div>
                        </div>
                        <div class="row" id="tb1">
                            <div class="col-md-8"></div>
                            <div class="col-md-4 form-check" style="text-align: right;">
                                <button type="button" class="btn btn-outline-primary waves-effect" onclick="document.getElementById('family2').style.display = 'block', document.getElementById('tb1').style.display = 'none'">
                                    <span class="ti-xs ti ti-plus me-1"></span><?= get_phrase('Add another Family Member') ?>
                                </button>
                            </div>
                        </div>

                        <!-- FI2 -->
                        <div id="family2" style="display:none;">
                            <hr/>
                            <br/>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('relationship') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <select name="family_relationship_2"  id="family_relationship" class="form-control">   
                                        <option value="" style="color: #7467f0;"><?= get_phrase('Select the relationship') ?></option>
                                        <option value="Father"><?= get_phrase('Father') ?></option>
                                        <option value="Mother"><?= get_phrase('Mother') ?></option>
                                        <option value="Grand mother"><?= get_phrase('Grand Mother') ?></option>
                                        <option value="Grand Father"><?= get_phrase('Grand Father') ?></option>
                                        <option value="Elder Brother"><?= get_phrase('Elder Brother') ?></option>
                                        <option value="Younger Brother"><?= get_phrase('Younger Brother') ?></option>
                                        <option value="Elder Sister"><?= get_phrase('Elder Sister') ?></option>
                                        <option value="Younger Sister"><?= get_phrase('Younger Sister') ?></option>
                                    </select>
                                </div>
                                <div class="col-md-2"><?= get_phrase('first_name_and_last_name') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="text" id="kanji_lname" name="family_first_and_lastname_2" class="form-control" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('date_of_birth') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="date" id="kanji_fname" name="family_dob_2" class="form-control" />
                                </div>
                                <div class="col-md-2"><?= get_phrase('Profession') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="text" id="kanji_lname" name="family_profession_2" class="form-control" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('current_address_family') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <textarea class="form-control" name="family_current_address_2" id="" rows="3"></textarea>
                                </div>
                                <div class="col-md-2"><?= get_phrase('life_and_death') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="radio" id="family_life_and_death1" name="family_life_and_death_2" value="Life">
                                    <label for="family_life_and_death1" class="me-5"><?= get_phrase('Life') ?></label>
                                    <input type="radio" id="family_life_and_death1" name="family_life_and_death_2" value="Death">
                                    <label for="family_life_and_death1" class="me-5"><?= get_phrase('Death') ?></label>
                                </div>
                            </div>
                            <div class="row" id="tb2">
                                <div class="col-md-8"></div>
                                <div class="col-md-4 form-check" style="text-align: right;">
                                    <button type="button" class="btn btn-outline-primary waves-effect" onclick="document.getElementById('family3').style.display = 'block', document.getElementById('tb2').style.display = 'none'">
                                        <span class="ti-xs ti ti-plus me-1"></span><?= get_phrase('Add another Family Member') ?>
                                    </button>
                                </div>
                            </div>
                        </div>


                        <!-- FI3 -->
                        <div id="family3" style="display:none;">
                            <hr/>
                            <br/>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('relationship') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <select name="family_relationship_3"  id="family_relationship" class="form-control">   
                                        <option value="" style="color: #7467f0;"><?= get_phrase('Select the relationship') ?></option>
                                        <option value="Father"><?= get_phrase('Father') ?></option>
                                        <option value="Mother"><?= get_phrase('Mother') ?></option>
                                        <option value="Grand mother"><?= get_phrase('Grand Mother') ?></option>
                                        <option value="Grand Father"><?= get_phrase('Grand Father') ?></option>
                                        <option value="Elder Brother"><?= get_phrase('Elder Brother') ?></option>
                                        <option value="Younger Brother"><?= get_phrase('Younger Brother') ?></option>
                                        <option value="Elder Sister"><?= get_phrase('Elder Sister') ?></option>
                                        <option value="Younger Sister"><?= get_phrase('Younger Sister') ?></option>
                                    </select>
                                </div>
                                <div class="col-md-2"><?= get_phrase('first_name_and_last_name') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="text" id="kanji_lname" name="family_first_and_lastname_3" class="form-control" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('date_of_birth') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="date" id="kanji_fname" name="family_dob_3" class="form-control" />
                                </div>
                                <div class="col-md-2"><?= get_phrase('Profession') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="text" id="kanji_lname" name="family_profession_3" class="form-control" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('current_address_family') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <textarea class="form-control" name="family_current_address_3" id="" rows="3"></textarea>
                                </div>
                                <div class="col-md-2"><?= get_phrase('life_and_death') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="radio" id="family_life_and_death1" name="family_life_and_death_3" value="Life">
                                    <label for="family_life_and_death1" class="me-5"><?= get_phrase('Life') ?></label>
                                    <input type="radio" id="family_life_and_death1" name="family_life_and_death_3" value="Death">
                                    <label for="family_life_and_death1" class="me-5"><?= get_phrase('Death') ?></label>
                                </div>
                            </div>
                            <div class="row" id="tb3">
                                <div class="col-md-8"></div>
                                <div class="col-md-4 form-check" style="text-align: right;">
                                    <button type="button" class="btn btn-outline-primary waves-effect" onclick="document.getElementById('family4').style.display = 'block', document.getElementById('tb3').style.display = 'none'">
                                        <span class="ti-xs ti ti-plus me-1"></span><?= get_phrase('Add another Family Member') ?>
                                    </button>
                                </div>
                            </div>
                        </div>

                         <!-- FI4 -->
                        <div id="family4" style="display:none;">
                            <hr/>
                            <br/>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('relationship') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <select name="family_relationship_4"  id="family_relationship" class="form-control">   
                                        <option value="" style="color: #7467f0;"><?= get_phrase('Select the relationship') ?></option>
                                        <option value="Father"><?= get_phrase('Father') ?></option>
                                        <option value="Mother"><?= get_phrase('Mother') ?></option>
                                        <option value="Grand mother"><?= get_phrase('Grand Mother') ?></option>
                                        <option value="Grand Father"><?= get_phrase('Grand Father') ?></option>
                                        <option value="Elder Brother"><?= get_phrase('Elder Brother') ?></option>
                                        <option value="Younger Brother"><?= get_phrase('Younger Brother') ?></option>
                                        <option value="Elder Sister"><?= get_phrase('Elder Sister') ?></option>
                                        <option value="Younger Sister"><?= get_phrase('Younger Sister') ?></option>
                                    </select>
                                </div>
                                <div class="col-md-2"><?= get_phrase('first_name_and_last_name') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="text" id="kanji_lname" name="family_first_and_lastname_4" class="form-control" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('date_of_birth') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="date" id="kanji_fname" name="family_dob_4" class="form-control" />
                                </div>
                                <div class="col-md-2"><?= get_phrase('Profession') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="text" id="kanji_lname" name="family_profession_4" class="form-control" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('current_address_family') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <textarea class="form-control" name="family_current_address_4" id="" rows="3"></textarea>
                                </div>
                                <div class="col-md-2"><?= get_phrase('life_and_death') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="radio" id="family_life_and_death1" name="family_life_and_death_4" value="Life">
                                    <label for="family_life_and_death1" class="me-5"><?= get_phrase('Life') ?></label>
                                    <input type="radio" id="family_life_and_death1" name="family_life_and_death_3" value="Death">
                                    <label for="family_life_and_death1" class="me-5"><?= get_phrase('Death') ?></label>
                                </div>
                            </div>
                            <div class="row" id="tb4">
                                <div class="col-md-8"></div>
                                <div class="col-md-4 form-check" style="text-align: right;">
                                    <button type="button" class="btn btn-outline-primary waves-effect" onclick="document.getElementById('family5').style.display = 'block', document.getElementById('tb4').style.display = 'none'">
                                        <span class="ti-xs ti ti-plus me-1"></span><?= get_phrase('Add another Family Member') ?>
                                    </button>
                                </div>
                            </div>
                        </div>

                          <!-- FI5 -->
                        <div id="family5" style="display:none;">
                            <hr/>
                            <br/>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('relationship') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <select name="family_relationship_5"  id="family_relationship" class="form-control">   
                                        <option value="" style="color: #7467f0;"><?= get_phrase('Select the relationship') ?></option>
                                        <option value="Father"><?= get_phrase('Father') ?></option>
                                        <option value="Mother"><?= get_phrase('Mother') ?></option>
                                        <option value="Grand mother"><?= get_phrase('Grand Mother') ?></option>
                                        <option value="Grand Father"><?= get_phrase('Grand Father') ?></option>
                                        <option value="Elder Brother"><?= get_phrase('Elder Brother') ?></option>
                                        <option value="Younger Brother"><?= get_phrase('Younger Brother') ?></option>
                                        <option value="Elder Sister"><?= get_phrase('Elder Sister') ?></option>
                                        <option value="Younger Sister"><?= get_phrase('Younger Sister') ?></option>
                                    </select>
                                </div>
                                <div class="col-md-2"><?= get_phrase('first_name_and_last_name') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="text" id="kanji_lname" name="family_first_and_lastname_5" class="form-control" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('date_of_birth') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="date" id="kanji_fname" name="family_dob_5" class="form-control" />
                                </div>
                                <div class="col-md-2"><?= get_phrase('Profession') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="text" id="kanji_lname" name="family_profession_5" class="form-control" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-2"><?= get_phrase('current_address_family') ?>:
                                </div>
                                <div class="col-md-4 form-check ">
                                    <textarea class="form-control" name="family_current_address_5" id="" rows="3"></textarea>
                                </div>
                                <div class="col-md-2"><?= get_phrase('life_and_death') ?>:
                                    <br>
                                    <smal style="font-size: x-small;color: #7467f0;">(<?= get_phrase('Describe only death') ?> )</smal>
                                </div>
                                <div class="col-md-4 form-check ">
                                    <input type="radio" id="family_life_and_death1" name="family_life_and_death_5" value="Life">
                                    <label for="family_life_and_death1" class="me-5"><?= get_phrase('Life') ?></label>
                                    <input type="radio" id="family_life_and_death1" name="family_life_and_death_5" value="Death">
                                    <label for="family_life_and_death1" class="me-5"><?= get_phrase('Death') ?></label>
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
            <br><br>
            <div class="card">
                <div class="card-body">
                    <div id="account-details" class="content">
                        <div class="content-header mb-3">
                            <h5 class="mb-0"><?= get_phrase('Sponsor Information') ?></h5>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('sponsor_surname') ?>: </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="kanji_fname" name="sponsor_surname" class="form-control" />
                            </div>
                            <div class="col-md-2"><?= get_phrase('Sposor name') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="kanji_lname" name="sponsor_name" class="form-control" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('relationship') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="kanji_fname" name="sponsor_relationship" class="form-control" />
                            </div>
                            <div class="col-md-2"><?= get_phrase('Sposor present address') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <textarea class="form-control" name="sponsor_present_address" id="" rows="3" placeholder=""></textarea>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Annual Income of Sponsor') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="sponsor_annual_income" name="sponsor_annual_income"  placeholder="<?= get_phrase('Local currency unit ＋ number') ?>" class="form-control" />
                            </div>
                            <div class="col-md-2"><?= get_phrase('Sponsor company') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="kanji_fname" name="sponsor_company" class="form-control" />
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Position of Sponsor') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="kanji_lname" name="sponsor_position" class="form-control" />
                            </div>
                            <div class="col-md-2"><?= get_phrase('Sponsor company address') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <textarea class="form-control" name="sponsor_company_address" id="" rows="3" placeholder=""></textarea>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('Contact (sp_fixed)') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="tel" id="kanji_fname"   name="sponsor_contact_sp_fixed" class="form-control" />
                            </div>
                            <div class="col-md-2"><?= get_phrase('contact (sp_mobile)') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="tel" id="kanji_fname"   name="sponsor_contact_sp_mobile" class="form-control" />
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"><?= get_phrase('contact (sp_w_fixed)') ?>:
                            </div>
                            <div class="col-md-4 form-check ">
                                <input type="text" id="kanji_lname"   name="sponsor_contact_sp_w_fixed" class="form-control" />
                            </div>
                            <div class="col-md-6">

                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>

</form>


<script src="<?php echo base_url('assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js'); ?>"></script>